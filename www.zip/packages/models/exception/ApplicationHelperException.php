<?php
namespace packages\models\exception;
use Exception;
class ApplicationHelperException extends Exception{
  
}