<?php
namespace packages\models\exception;
use Exception;
class AbstractObjectException extends Exception {
  
}
