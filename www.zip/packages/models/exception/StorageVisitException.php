<?php
namespace packages\models\exception;
use Exception;
class StorageVisitException extends Exception{}