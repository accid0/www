<?php
namespace packages\view\exception;
use Exception;
class BuilderChainException extends Exception {
  
}
