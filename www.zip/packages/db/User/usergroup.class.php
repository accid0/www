<?php
class Usergroup extends xPDOObject {}