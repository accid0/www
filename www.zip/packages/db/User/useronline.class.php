<?php
class Useronline extends xPDOObject {}