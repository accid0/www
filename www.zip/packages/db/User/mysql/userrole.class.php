<?php
require_once (dirname(dirname(__FILE__)) . '/userrole.class.php');
class Userrole_mysql extends Userrole {}