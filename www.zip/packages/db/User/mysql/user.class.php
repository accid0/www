<?php
require_once (dirname(dirname(__FILE__)) . '/user.class.php');
class User_mysql extends User {}