<?php
require_once (dirname(dirname(__FILE__)) . '/shoparticles.class.php');
class ShopArticles_mysql extends ShopArticles {}