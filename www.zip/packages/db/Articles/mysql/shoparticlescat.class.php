<?php
require_once (dirname(dirname(__FILE__)) . '/shoparticlescat.class.php');
class ShopArticlesCat_mysql extends ShopArticlesCat {}