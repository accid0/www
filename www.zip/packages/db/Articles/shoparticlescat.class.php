<?php
class ShopArticlesCat extends xPDOObject {}