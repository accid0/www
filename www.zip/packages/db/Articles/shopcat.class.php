<?php
class ShopCat extends xPDOObject {}