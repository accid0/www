<?php
namespace packages\view\plugins;
interface AuthPlugin{
  /**
   * @return array
   * Enter description here ...
   */
  function getRole();
}