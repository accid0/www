<?php

namespace packages\view\expression;

class NullExpression extends Expression {
  function __construct(){
  }
	
}