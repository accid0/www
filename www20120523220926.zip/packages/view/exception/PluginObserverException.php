<?php
namespace packages\view\exception;
use Exception;
class PluginObserverException extends Exception {
  
}
