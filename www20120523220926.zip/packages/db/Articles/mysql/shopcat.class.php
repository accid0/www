<?php
require_once (dirname(dirname(__FILE__)) . '/shopcat.class.php');
class ShopCat_mysql extends ShopCat {}