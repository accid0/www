<?php
class ShopArticles extends xPDOSimpleObject {}