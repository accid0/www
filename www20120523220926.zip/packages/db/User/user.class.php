<?php
class User extends xPDOObject {}