<?php
class Userrole extends xPDOObject {}