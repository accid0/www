<?php
require_once (dirname(dirname(__FILE__)) . '/usergroup.class.php');
class Usergroup_mysql extends Usergroup {}