<?php
require_once (dirname(dirname(__FILE__)) . '/useronline.class.php');
class Useronline_mysql extends Useronline {}