<?php
namespace packages\models\visitorer;

class NullVisitorer extends Visitorer {

}