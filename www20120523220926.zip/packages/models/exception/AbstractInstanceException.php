<?php
namespace packages\models\exception;
use Exception;
class AbstractInstanceException extends Exception {
  
}
