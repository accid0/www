<?php
namespace packages\models\exception;
use Exception;
class StorageDetachException extends Exception {
  
}
