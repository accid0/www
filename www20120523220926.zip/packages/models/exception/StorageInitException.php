<?php
namespace packages\models\exception;
use Exception;
class StorageInitException extends Exception {
  
}
