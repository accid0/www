<?php
namespace packages\models\exception;
use Exception;
class StorageCallException extends Exception {
  
}
