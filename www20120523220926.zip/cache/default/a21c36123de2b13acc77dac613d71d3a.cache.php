<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'value' => 
      array (
        0 => '22277a9157d2c2d97fe77e5a1030da5c',
        1 => '64fd1d56a51ed8c122ab3cadc55a3d79',
        2 => '0c9f2e4a887bf323285c211854801f2c',
      ),
    ),
    'attributes' => 
    array (
      'value' => '24',
      'name' => 'maxNameLenght',
    ),
    'value' => '',
  ),
);