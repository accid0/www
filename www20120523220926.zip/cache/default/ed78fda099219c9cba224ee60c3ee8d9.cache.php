<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => 'b1037196320345cd9ca9a4a6f1c9121d',
        1 => '56e80615970e062b94606a73b72c84cf',
      ),
    ),
    'attributes' => 
    array (
      'id' => 'User',
    ),
    'value' => '
	
	',
  ),
);