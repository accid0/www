<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'expression' => 
      array (
        0 => '659106f14c7b1c8699157512aff839e7',
        1 => '05637572e1ba22c036ee0a10cbeec6b1',
        2 => '78b943197ccbf51a1e05865cdaf0df46',
        3 => '2fd277c2a9f5c7558ee1d191e5875b21',
        4 => 'ed31bb5d084c74cc0f0073c183a3f2a1',
        5 => '64c1d1cde43062182950f8782350f130',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '
	',
  ),
);