<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => 'c60139bc867dfc1e9408457b353b2106',
      ),
      'permissions' => 
      array (
        0 => 'b91d57f1bb856c30a3c9f97aa797160b',
      ),
      'lang' => 
      array (
        0 => 'bdec7c5804db7752408a74e1cc1edefc',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Url',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);