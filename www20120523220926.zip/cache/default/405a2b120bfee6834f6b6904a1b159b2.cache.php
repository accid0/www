<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '6e0eb9757b6c61cf587caa62f7fd7d80',
      ),
      'permissions' => 
      array (
        0 => 'ae3f7f89c07fc59b49d4b53f4a934780',
      ),
      'lang' => 
      array (
        0 => '27c83dd0f3937964ee2916ef1f4d0948',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Request',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);