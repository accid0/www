<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => 
  array (
    'User' => 'Пользователи',
    'User.userId' => 'ИД',
    'User.uname' => 'Ф.И.О.',
    'UserGroup.groupname' => 'Роли',
    'User.email' => 'Почта',
  ),
);