<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => 
  array (
    'User' => 'Users',
    'User.userId' => 'ID',
    'User.uname' => 'Name',
    'UserGroup.groupname' => 'Rols',
    'User.email' => 'Email',
  ),
);