<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => '444d15399bc419eef07847521be05ade',
        1 => '72c8527e7cb3fdf8afe05bbd4d41618d',
      ),
    ),
    'attributes' => 
    array (
      'id' => 'User.email',
    ),
    'value' => '
    
    
    ',
  ),
);