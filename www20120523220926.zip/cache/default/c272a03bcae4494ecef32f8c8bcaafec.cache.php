<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'system' => 
      array (
        0 => '2281f356ca798818f214761e9ea7243b',
      ),
      'modules' => 
      array (
        0 => '1a09f3d450641f7247f8d9cdaa83950b',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '
		
		',
  ),
);