<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'option' => 
      array (
        0 => 'a21c36123de2b13acc77dac613d71d3a',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '',
  ),
);