<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'plugin' => 
      array (
        0 => 'f3ab047a07d0b194a55af8c7d335175f',
        1 => '5fd5f13639fa2d04fcfae67da2096e37',
        2 => '3648d797623568b7378d1d4067939d48',
        3 => '405a2b120bfee6834f6b6904a1b159b2',
        4 => 'fc432b35b7fa8893fda2025dbf968b0a',
        5 => '194b3fc921320dda419555c4f982bbbc',
        6 => '1404cc3a909dfb8f5a03f2f71adab9a5',
        7 => 'c24e0b68f0d512b5f07f6c5a0f5b8044',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '',
  ),
);