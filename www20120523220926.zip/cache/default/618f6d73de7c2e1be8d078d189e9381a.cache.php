<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'value' => 
      array (
        0 => '9ccf107723c3ee93090cf601c32b4757',
        1 => '10288842dfeb86cb7a6fe40a137e2e47',
        2 => 'baf3fc816e38c6533f5fbdc84871778f',
      ),
    ),
    'attributes' => 
    array (
      'value' => '24',
      'name' => 'maxNameLenght',
    ),
    'value' => '',
  ),
);