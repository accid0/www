<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'option' => 
      array (
        0 => 'd1c24f3eb61799f9136d92de20c0eb06',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '',
  ),
);