<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => 'd0f3f6988a79aef0d3457b2d16759c2c',
      ),
      'permissions' => 
      array (
        0 => 'fa35c0d58d9dca219ecec7b9faed6709',
      ),
      'lang' => 
      array (
        0 => '8c1e677ffd70dd5d3045e003794b23ed',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Extend',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);