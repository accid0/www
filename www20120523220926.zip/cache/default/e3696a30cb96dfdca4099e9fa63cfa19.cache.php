<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => 'a0469b9e3757f77d40b77c8ef9c466d5',
      ),
      'permissions' => 
      array (
        0 => '8d35953bf5d646f40080099e4c5be313',
      ),
      'lang' => 
      array (
        0 => 'fdc44be5768218a01c808e0ba8fcffa9',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Lang',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);