<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '562f38bd7d44b6e72d120d805809d4c1',
      ),
      'permissions' => 
      array (
        0 => '390f1b7e2334ac0c90776600347eca03',
      ),
      'lang' => 
      array (
        0 => '3763428e3cff22ae378dc2555ee402c2',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Server',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);