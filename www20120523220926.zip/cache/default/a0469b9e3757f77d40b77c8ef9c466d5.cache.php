<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'option' => 
      array (
        0 => 'abba8d863a749a8e40ab29bf1a24c2bc',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '',
  ),
);