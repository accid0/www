<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'plugin' => 
      array (
        0 => '389512ca5a6a3bb2b724a756cf4da169',
        1 => '63d023113353fbeeeec6026de7da5161',
        2 => 'a23d69f857795e21034ce8f707b5b28d',
        3 => 'df8619f4c9294c0a8ef08d4801e9b3b9',
        4 => '8fecfcc2df2685b830869c8225e2af81',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '',
  ),
);