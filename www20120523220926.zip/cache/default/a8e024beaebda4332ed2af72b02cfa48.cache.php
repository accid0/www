<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => '0aef25a281433d4bd4030a4f4fea2541',
        1 => 'eb8d414bec512eece2e201a86e5c5ff9',
      ),
    ),
    'attributes' => 
    array (
      'id' => 'User.userId',
    ),
    'value' => '
	
    
    ',
  ),
);