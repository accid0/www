<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '5741bff5a5eb1a4391054cba51125b64',
      ),
      'permissions' => 
      array (
        0 => '5356efe9ba401982ad39c70ec98358a6',
      ),
      'lang' => 
      array (
        0 => '9fc26f976160c0798afae0b94da31dbb',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'User',
      'access' => 'enable',
      'cache' => 'false',
      'package' => 'User',
    ),
    'value' => '',
  ),
);