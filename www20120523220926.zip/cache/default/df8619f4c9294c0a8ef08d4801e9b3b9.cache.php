<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '5a273607d16dc4f43247540321d75aa8',
      ),
      'permissions' => 
      array (
        0 => '79ff2f2019527143d22f5e7d8ee56cf0',
      ),
      'lang' => 
      array (
        0 => 'dc2e0553c997616525f1a8fee8636383',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Lang',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);