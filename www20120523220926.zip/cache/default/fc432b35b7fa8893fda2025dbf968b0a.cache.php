<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '7a267b43c2205e8db81b4712e75674ca',
      ),
      'permissions' => 
      array (
        0 => '14ef7556364402403f9e89cdcaa0fa3a',
      ),
      'lang' => 
      array (
        0 => '354a264ba5fab73cbc83ba74ab0dcc72',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Cookies',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);