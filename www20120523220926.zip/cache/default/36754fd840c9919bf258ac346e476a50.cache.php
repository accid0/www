<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
    ),
    'attributes' => 
    array (
      'name' => 'en_EN',
      'value' => 'Name',
    ),
    'value' => '',
  ),
);