<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => '0888a07fab4a4beeba01127c6c873b2e',
        1 => 'fab52a63486b24aafb82872ba7d661d5',
      ),
    ),
    'attributes' => 
    array (
      'id' => 'UserGroup.groupname',
    ),
    'value' => '
    
    
    ',
  ),
);