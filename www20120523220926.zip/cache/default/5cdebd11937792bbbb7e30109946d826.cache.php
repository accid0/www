<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => 'af643a2b904f4f691a91920624de0347',
        1 => '8023eb75ad191fd6de6a1d621cf88491',
      ),
    ),
    'attributes' => 
    array (
      'id' => '',
    ),
    'value' => '
    ',
  ),
);