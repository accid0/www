<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => 'df1303e1ad5ecc8596cf2ad76c1b1f18',
        1 => 'a990ccb8ae68b83cfb9fcc5262c3cb68',
      ),
    ),
    'attributes' => 
    array (
      'id' => 'User.userId',
    ),
    'value' => '
	
    
    ',
  ),
);