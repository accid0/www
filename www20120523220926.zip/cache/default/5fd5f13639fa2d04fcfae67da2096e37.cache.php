<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '7bc9a3115f4dc7192a3f448b939ab196',
      ),
      'permissions' => 
      array (
        0 => '2b13c2270e2fe92aef6ebe791bc245ac',
      ),
      'lang' => 
      array (
        0 => 'be038094c565124bca6a0a603f3715ca',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Session',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);