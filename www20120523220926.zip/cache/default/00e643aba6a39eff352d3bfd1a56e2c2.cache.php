<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => 'a817e1dde24f8bcb1635a075317394eb',
      ),
      'permissions' => 
      array (
        0 => '0e4be788864aa0d7e10a03de847d7652',
      ),
      'lang' => 
      array (
        0 => '0dc081e207c1b937508832265078a4fd',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Datatable',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);