<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
    ),
    'attributes' => 
    array (
    ),
    'value' => '',
  ),
);