<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => 'a8725059c01d6803f26709aa41576171',
        1 => '2a5c2dbab99380d3ff844de2a90d73e1',
      ),
    ),
    'attributes' => 
    array (
      'id' => 'UserGroup.groupname',
    ),
    'value' => '
    
    
    ',
  ),
);