<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => '0dd1f7f1a6a45f894cf6d4a461317f6b',
        1 => 'e500b900fa5a8ca89c8edbc63c9e2026',
      ),
    ),
    'attributes' => 
    array (
      'id' => 'User',
    ),
    'value' => '
	
	',
  ),
);