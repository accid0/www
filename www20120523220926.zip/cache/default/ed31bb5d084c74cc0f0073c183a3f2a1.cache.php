<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => 'd73d62417b2829b7bc6fa80936a23a0d',
        1 => 'a2d605699669f7638a640020fb41aa4c',
      ),
    ),
    'attributes' => 
    array (
      'id' => 'User.email',
    ),
    'value' => '
    
    
    ',
  ),
);