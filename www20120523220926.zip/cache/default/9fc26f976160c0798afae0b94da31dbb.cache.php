<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'expression' => 
      array (
        0 => 'ed78fda099219c9cba224ee60c3ee8d9',
        1 => 'a8e024beaebda4332ed2af72b02cfa48',
        2 => 'ad3f5a6d276ef813614913f865bb730c',
        3 => '4d8bc0a5c8a29cd3b2ec6fc60810040e',
        4 => 'b2f7e3dcb7fb6cf231af283295ce9baa',
        5 => '5cdebd11937792bbbb7e30109946d826',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '
	',
  ),
);