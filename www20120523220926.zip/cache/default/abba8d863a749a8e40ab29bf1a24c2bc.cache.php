<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'value' => 
      array (
        0 => 'b655a038505a3ecf0cfcb04cf9e7643f',
        1 => 'ce7a3258e64cc471afc028fc13f4acda',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'defaultLocale',
      'value' => 'ru_RU',
    ),
    'value' => '',
  ),
);