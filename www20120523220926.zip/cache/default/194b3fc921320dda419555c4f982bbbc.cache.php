<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '785b6d4e8910ddd3ec8413ec502a495f',
      ),
      'permissions' => 
      array (
        0 => '23b7e6b1da17b0c7f573a87355c75f63',
      ),
      'lang' => 
      array (
        0 => 'e7f2bf251eb6ace9525b7c6ae1800adc',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Assign',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);