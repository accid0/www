<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '3da4bd128a387214d96ea2660ddcd7ae',
      ),
      'permissions' => 
      array (
        0 => '25996e297bec09907169173ba9192839',
      ),
      'lang' => 
      array (
        0 => '2beb8b0a1c06cb67803213160f1f2068',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'User',
      'access' => 'enable',
      'cache' => 'false',
      'package' => 'User',
    ),
    'value' => '',
  ),
);