<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'templateFolder' => 
      array (
        0 => '6f18036e3665fede089c6f558ac74b86',
      ),
      'cacheFolder' => 
      array (
        0 => '0d96762c8cc301a3863637f5a0bdee0a',
      ),
      'baseurl' => 
      array (
        0 => '1e6d1f9ef95cc649d4049eb4678b4e3b',
      ),
      'errorPage' => 
      array (
        0 => '8fa75b9b7006974e32d391481c629539',
      ),
      'pluginFolder' => 
      array (
        0 => '2cc0f987a07f400b4d2f132d45f1428c',
      ),
      'authPlugin' => 
      array (
        0 => 'e2988fd4a9b50c593a7275fa7ecb9942',
      ),
      'controllersFolder' => 
      array (
        0 => '96ca0d9e41e763899ed2d6e247f616d4',
      ),
      'viewsFolder' => 
      array (
        0 => 'd15ef22c70d4b376abbfce46936af469',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '
		
		
		
		
		
		
		
		',
  ),
);