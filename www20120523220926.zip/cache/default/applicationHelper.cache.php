<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'application' => 
      array (
        0 => 'c1af4416fd24b83f1191c4dd63bba665',
      ),
      'plugins' => 
      array (
        0 => 'c272a03bcae4494ecef32f8c8bcaafec',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '
	
	',
  ),
);