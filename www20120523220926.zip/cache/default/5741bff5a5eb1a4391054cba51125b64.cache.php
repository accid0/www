<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'option' => 
      array (
        0 => '618f6d73de7c2e1be8d078d189e9381a',
      ),
    ),
    'attributes' => 
    array (
    ),
    'value' => '',
  ),
);