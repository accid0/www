<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => 'f9b8f449589e0f6625da36a3e535748d',
      ),
      'permissions' => 
      array (
        0 => 'b6bc58ff19c8f068ae101a3908595ccb',
      ),
      'lang' => 
      array (
        0 => '3e59aa37eec744071c09b1d438fd318a',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'ApplicationHelper',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);