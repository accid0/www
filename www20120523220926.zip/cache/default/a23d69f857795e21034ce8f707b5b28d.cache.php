<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '1ae4a5d325799c632c28348a56e26af3',
      ),
      'permissions' => 
      array (
        0 => '66cd82c28988e700b246e8830da8588f',
      ),
      'lang' => 
      array (
        0 => '9d928591ee81999a60213ee71aeb41e4',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Datatable',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);