<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => 'a7f6d09632f25eae9f3b547dc7ea6250',
        1 => '36754fd840c9919bf258ac346e476a50',
      ),
    ),
    'attributes' => 
    array (
      'id' => 'User.uname',
    ),
    'value' => '
    
    
    ',
  ),
);