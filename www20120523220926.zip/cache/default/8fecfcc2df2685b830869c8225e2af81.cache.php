<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '95b947780fbdc36121a2d6428ca6a12a',
      ),
      'permissions' => 
      array (
        0 => '48c082fbaaea84edc0d56180ec47b528',
      ),
      'lang' => 
      array (
        0 => '947ccc4c8f8487daf54c45f5f0f92e41',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Form',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);