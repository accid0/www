<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => '0878c3bec74805c484ad986e3140cbfc',
      ),
      'permissions' => 
      array (
        0 => 'e18bf1eba4ea354982cfe206d6853ced',
      ),
      'lang' => 
      array (
        0 => 'a1641e89341fb2a9a9988748ffb8cf5d',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Registry',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);