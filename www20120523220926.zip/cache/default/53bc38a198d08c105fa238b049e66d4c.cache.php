<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'options' => 
      array (
        0 => 'aa5b5e76bc77167c5772b13dd2a2b99a',
      ),
      'permissions' => 
      array (
        0 => '2d61faad22da8b23511ae14a934c4ee0',
      ),
      'lang' => 
      array (
        0 => '4a5795d0c4b5d1847ec7c4258aa5623c',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'Url',
      'access' => 'enable',
      'cache' => 'false',
    ),
    'value' => '',
  ),
);