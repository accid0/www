<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => '912083569820b1fbfaaa424e8f825dd3',
        1 => 'd1caaffca9f34ac5b2d4f603841da6e0',
      ),
    ),
    'attributes' => 
    array (
      'id' => '',
    ),
    'value' => '
    ',
  ),
);