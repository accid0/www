<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'value' => 
      array (
        0 => 'bd2d5e1fb3589939e6e0be6cfce3d638',
        1 => 'cb4a594479fddfe037d7cad5b3c01ed7',
      ),
    ),
    'attributes' => 
    array (
      'name' => 'defaultLocale',
      'value' => 'ru_RU',
    ),
    'value' => '',
  ),
);