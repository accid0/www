<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => '53bc38a198d08c105fa238b049e66d4c',
);