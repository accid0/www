<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => '3648d797623568b7378d1d4067939d48',
);