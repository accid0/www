<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => 'e3696a30cb96dfdca4099e9fa63cfa19',
);