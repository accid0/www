<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => '405a2b120bfee6834f6b6904a1b159b2',
);