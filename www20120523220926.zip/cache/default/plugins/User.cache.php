<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => 'e2efb6a3eb66c53c8ffb2629520376c1',
);