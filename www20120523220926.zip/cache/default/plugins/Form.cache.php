<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => '8fecfcc2df2685b830869c8225e2af81',
);