<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => '00e643aba6a39eff352d3bfd1a56e2c2',
);