<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => '5fd5f13639fa2d04fcfae67da2096e37',
);