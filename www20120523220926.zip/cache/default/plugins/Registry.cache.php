<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => 'f3ab047a07d0b194a55af8c7d335175f',
);