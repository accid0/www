<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => 'fc432b35b7fa8893fda2025dbf968b0a',
);