<?php  return array (
  'tags' => 
  array (
    'commonApplication' => 1,
  ),
  'data' => 'c24e0b68f0d512b5f07f6c5a0f5b8044',
);