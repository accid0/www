<?php  return array (
  'tags' => 
  array (
    'applicationHelper' => 0,
  ),
  'data' => 
  array (
    'children' => 
    array (
      'locale' => 
      array (
        0 => '926dbd93aafb1e26e41597e5bac70920',
        1 => '3f95014c5eadf009e30754b27e63d0e3',
      ),
    ),
    'attributes' => 
    array (
      'id' => 'User.uname',
    ),
    'value' => '
    
    
    ',
  ),
);